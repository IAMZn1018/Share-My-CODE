# -*-coding:utf-8-*-

import requests
import xlwt
import csv
from bs4 import BeautifulSoup
from requests.exceptions import RequestException


# 获取url的Soup
def get_one_page(url, headers):
    try:
        html = requests.get(url, headers=headers)
        if html.status_code == 200:
            html.coding = 'utf-8'
            Soup = BeautifulSoup(html.content, 'lxml')
            return Soup
        return None
    except RequestException:
        print('请求页索引出错')
        return None


# 获取最大页数
def get_all_python_maxPage(Soup):
    for i in range(0, 99):
        if Soup.find('div', class_='pagesDown').find_all('a')[i].get_text() == '下一页':
            return i


# 获取第i个职位，子url，反馈率，公司，公司介绍url信息
def get_childUrl_and_otherMessage(Soup, i):
    position = Soup.find('div', class_='newlist_list_content').find_all('td', class_='zwmc')[i].find('a').get_text()
    child_url = Soup.find('div', class_='newlist_list_content').find_all('td', class_='zwmc')[i].find('a').attrs['href']
    feed_back = Soup.find('div', class_='newlist_list_content').find_all('td', class_='fk_lv')[i].find(
        'span').get_text()
    company = Soup.find('div', class_='newlist_list_content').find_all('td', class_='gsmc')[i].find('a').get_text()
    company_url = Soup.find('div', class_='newlist_list_content').find_all('td', class_='gsmc')[i].find('a').attrs[
        'href']
    if feed_back == '':
        feed_back = '无反馈记录'
    message_list = [position, child_url, feed_back, company, company_url]
    return message_list


# 获取子url
def get_child_url(Soup):
    url = []
    for i in range(0, len(Soup.find('div', class_='newlist_list_content').find_all('td', class_='zwmc')) - 1):
        url.append(
            Soup.find('div', class_='newlist_list_content').find_all('td', class_='zwmc')[i].find('a').attrs['href'])
    return url


# 将所有信息写入excel
def write_to_excel(all_data, filename):
    workbook = xlwt.Workbook(encoding='utf-8')
    booksheet = workbook.add_sheet('Sheet 1', cell_overwrite_ok=True)
    page = 1
    row = 0
    column = 0
    header = ['职位名称', '详情页面', '反馈率', '公司名称', '公司链接', '月薪', '工作地点', '发布日期', '工作性质', '工作经验', '最低学历', '招聘人数', '职位类别',
              '更多详情', '工作地点']
    for head in header:
        booksheet.write(row, column, head)
        column += 1
    row += 1

    for list_data in all_data:
        column = 0
        for each_data in list_data:
            booksheet.write(row, column, each_data)
            column += 1
        row += 1
    '''
    for page_data in all_data:
        for row_data in page_data:
            column = 0
            for each_data in row_data:
                booksheet.write(row, column, each_data)
                column += 1
            row += 1
        print('保存成功' + str(page) + '页')
        page += 1
    '''
    workbook.save(filename + '.xls')


# 将所有信息写入
def write_to_csv(all_data, filename):
    header = ['职位名称', '详情页面', '反馈率', '公司名称', '公司链接', '月薪', '工作地点', '发布日期', '工作性质', '工作经验', '最低学历', '招聘人数', '职位类别',
              '更多详情', '工作地点']

    with open(filename + '.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(header)  # 写入头
        writer.writerows(all_data)  #写入数据


# 获取子url页面下的详情
def get_childUrl_detail(url, headers):
    detail, location = '', ''
    all = []
    Soup = get_one_page(url, headers)
    # 8个li的信息
    for common in range(0, len(Soup.find('ul', class_='terminal-ul clearfix').find_all('li'))):
        all.append(Soup.find('ul', class_='terminal-ul clearfix').find_all('li')[common].get_text()[5:])  # 去掉前面的头部信息

    # 下面的详情信息
    if len(Soup.find('div', class_='tab-inner-cont').find_all('p')) < 2:
        for i in range(0, len(Soup.find('div', class_='tab-inner-cont').find_all('span'))):
            detail += Soup.find('div', class_='tab-inner-cont').find_all('span')[i].get_text().strip().replace('\xa0',
                                                                                                               '').replace(
                '\u3000', '')
        location = Soup.find('div', class_='tab-inner-cont').find('h2').get_text().replace('查看职位地图', '').strip()
        all.append(detail)
        all.append(location)
    else:
        for i in range(0, len(Soup.find('div', class_='tab-inner-cont').find_all('p'))):
            detail += Soup.find('div', class_='tab-inner-cont').find_all('p')[i].get_text().strip().replace('\xa0',
                                                                                                            '').replace(
                '\u3000', '')
        location = Soup.find('div', class_='tab-inner-cont').find('h2').get_text().replace('查看职位地图', '').strip()
        all.append(detail)
        all.append(location)

    return all


# 处理数据
def solve_data(index_url, headers, filename):
    Message = []
    index_url_Soup = get_one_page(index_url, headers=headers)
    max_page = get_all_python_maxPage(index_url_Soup)
    print('总共' + str(max_page) + '页')

    for page in range(1, max_page + 1):
        url = index_url + str(page)  # 主页的url
        url_Soup = get_one_page(url, headers=headers)  # 主页的Soup
        url_list = get_child_url(url_Soup)  # 当前页子url数组
        for child in range(0,
                           len(url_Soup.find('div', class_='newlist_list_content').find_all('td', class_='zwmc')) - 1):
            a = get_childUrl_and_otherMessage(url_Soup, child)
            try:
                b = get_childUrl_detail(url_list[child], headers)
            except:
                print(url_list[child])
            Message.append(a + b)
        print('第' + str(page) + '页获取成功')

    # write_to_excel(Message, filename)
    # print('excel写入成功')
    write_to_csv(Message, filename)
    print('csv写入成功')


def refactoring_url(place, name):
    return 'http://sou.zhaopin.com/jobs/searchresult.ashx?jl=' + place + '+&kw=' + name + '&p='


if __name__ == '__main__':
    location, work = '厦门', 'PHP'
    headers = {
        'User-Agent': "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/22.0.1207.1 Safari/537.1"}
    index_url = refactoring_url(location, work)
    print('开始抓取数据')
    # index_url = 'http://sou.zhaopin.com/jobs/searchresult.ashx?jl=%E5%8E%A6%E9%97%A8&kw=python&p='
    solve_data(index_url, headers, location + work)
