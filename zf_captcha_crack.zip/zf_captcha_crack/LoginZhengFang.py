﻿import random
import re

import shutil
import tensorflow as tf
import numpy as np
import requests
import time

from tensorflow_cnn_train import convert2gray
from tensorflow_cnn_train import vec2text

from tensorflow_cnn_train import MAX_CAPTCHA
from tensorflow_cnn_train import CHAR_SET_LEN
from tensorflow_cnn_train import X
from tensorflow_cnn_train import keep_prob

from tensorflow_cnn_train import crack_captcha_cnn
from bs4 import BeautifulSoup
from PIL import Image

import os
import os.path


class LoginZF:
    username, password, name = '', '', ''
    urlhead = 'http://jwxt.xxxx.edu.cn'
    selectcourse = urlhead + '/xf_xsqxxxk.aspx?xh={username}&xm={name}&gnmkdm=N121203'
    Login = urlhead + '/default2.aspx'
    checkNo = urlhead + '/xs_main.aspx?xh={username}'
    checkTimetable = urlhead + '/xskbcx.aspx?xh={username}&xm={name}&gnmkdm=N121603'
    checkScore = urlhead + '/xscjcx.aspx?xh={username}&xm={name}&gnmkdm=N121618'

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36",
    }

    postData = {
        '__EVENTTARGET': '',
        '__EVENTARGUMENT': '',
        '__VIEWSTATE': '',
        'hidLanguage': '',
        'ddlXN': '',  # 学年
        'ddlXQ': '',  # 学期
        'ddl_kcxz': '',  # 课程选择？
        'btn_zcj': '',  # 历年成绩
    }

    output = crack_captcha_cnn()
    saver = tf.train.Saver()
    sess = tf.Session()
    saver.restore(sess, ".model/crack_capcha.model-5700")

    def init(self):
        session = requests.session()
        return session

    # 验证码识别
    def crack_captcha(self, image, output, sess):

        image = convert2gray(image).flatten() / 255  # 一维化
        predict = tf.argmax(tf.reshape(output, [-1, MAX_CAPTCHA, CHAR_SET_LEN]), 2)

        text_list = sess.run(predict, feed_dict={X: [image], keep_prob: 1})

        text = text_list[0].tolist()
        vector = np.zeros(MAX_CAPTCHA * CHAR_SET_LEN)
        i = 0
        for n in text:
            vector[i * CHAR_SET_LEN + n] = 1
            i += 1

        predict_text = vec2text(vector)
        return predict_text

    # 查课表
    def Check_Timetable(self, session):
        Monday, Tuesday, Wednesday, Thursday, Fruday, Satuday, Sunday = [], [], [], [], [], [], []
        result = {}

        referer = self.checkNo
        referer = referer.format(username=self.username)
        headers = self.headers
        headers['referer'] = referer
        checkTimetable = self.checkTimetable.format(username=self.username, name=self.name)
        Response = session.post(checkTimetable, headers=headers)
        soup = BeautifulSoup(Response.text, 'lxml')
        result = soup.find('table', class_='blacktab').find_all('tr')
        for eachone in result:
            print(eachone)

    # 查所有成绩
    def Check_All_Score(self, session):
        result = {}
        course_name, credit, score, rescore = [], [], [], []
        referer = self.checkNo
        referer = referer.format(username=self.username)
        headers = self.headers
        headers["Referer"] = referer
        url = self.checkScore
        url = url.format(username=self.username, name=self.name)

        ResponseTest = session.get(url, headers=headers).text
        soup = BeautifulSoup(ResponseTest, 'lxml')
        __VIEWSTATE = soup.find_all('input')[2]['value']
        postdata = self.postData
        postdata['__VIEWSTATE'] = __VIEWSTATE
        postdata['btn_zcj'] = '历年成绩'.encode('gbk')
        Response = session.post(url, data=postdata, headers=headers)
        resultHtmlText = BeautifulSoup(Response.text, 'lxml')

        all_course = resultHtmlText.find('table', class_='datelist').find_all('tr')
        del all_course[0]
        for each_course in all_course:
            i = each_course.find_all('td')
            course_name.append(i[3].get_text())
            credit.append(i[6].get_text())
            score.append(i[8].get_text())
            rescore.append(i[10].get_text())

        result['课程名称'] = course_name
        result['学分'] = credit
        result['成绩'] = score
        for i in range(0, len(rescore)):
            if rescore[i] == '\xa0':
                rescore[i] = 'None'
        result['补考成绩'] = rescore
        return result

    # 查询当前学期成绩
    # 1/2
    # 2017-2018
    def Check_This_Score(self, session, xueqi, xuenian):  # 未完成
        result = {}
        course_name, credit, score, rescore = [], [], [], []

        referer = self.checkNo
        referer = referer.format(username=self.username)
        checkScore = self.checkScore
        checkScore = checkScore.format(username=self.username, name=self.name)
        postdata = self.postData
        headers = self.headers
        headers['referer'] = referer

        ResponseTest = session.get(checkScore, headers=headers).text
        soup = BeautifulSoup(ResponseTest, 'lxml')
        __VIEWSTATE = soup.find_all('input')[2]['value']
        postdata['__VIEWSTATE'] = __VIEWSTATE
        postdata.pop('btn_zcj')
        postdata['ddlXQ'] = xueqi
        postdata['ddlXN'] = xuenian
        postdata['btn_xq'] = '%D1%A7%C6%DA%B3%C9%BC%A8'
        Response = session.post(checkScore, data=postdata, headers=headers)
        resultHtmlText = BeautifulSoup(Response.text, 'lxml')

        all_course = resultHtmlText.find('table', class_='datelist').find_all('tr')
        del all_course[0]
        for each_course in all_course:
            i = each_course.find_all('td')
            course_name.append(i[3].get_text())
            credit.append(i[6].get_text())
            score.append(i[8].get_text())
            rescore.append(i[10].get_text())

        result["课程名称"] = course_name
        result["学分"] = credit
        result["成绩"] = score
        for i in range(0, len(rescore)):
            if rescore[i] == '\xa0':
                rescore[i] = 'None'
        result["补考成绩"] = rescore
        return result

    # 评价课程（未完成）
    def pingjiakecheng(self, session):  # 未完成
        url_list = []
        head = 'http://jwxt.xxxx.edu.cn/xsjxpj.aspx?'
        headers = self.headers
        headers['referer'] = 'http://jwxt.xxxx.edu.cn/xs_main.aspx?xh=1503103004'

        try:
            text = session.get('http://jwxt.xxxx.edu.cn/xs_main.aspx?xh=' + self.username).text
            text = BeautifulSoup(text, 'lxml')
            urls = text.find('ul', class_='nav').find_all('ul', class_='sub')[2]
            if urls == '':
                return
            else:
                a = urls.find_all('a')
                for url in a:
                    url_list.append(head + url['href'])

            for i in range(len(url_list) - 1):
                text = session.get(url_list[0], headers=headers).text
                text = BeautifulSoup(text, 'lxml')
                __VIEWSTATE = text.find_all('input')[2]['value']
        except:
            return

    # 选课
    def select_course(self, session, select):
        username = self.username
        name = self.name
        url = self.selectcourse
        url = url.format(username=username, name=name.encode('gbk'))
        referer = self.checkNo
        referer = referer.format(username=self.username)
        headers = self.headers
        headers["Referer"] = referer
        response = session.get(url, headers=headers)
        text = BeautifulSoup(response.text, 'lxml')
        __VIEWSTATE = text.find_all('input')[2]['value']

        finddata = {
            '__EVENTTARGET': '',
            '__EVENTARGUMENT': '',
            '__VIEWSTATE': __VIEWSTATE,
            'ddl_kcxz': '',
            'ddl_ywyl': '有'.encode('gbk'),  # 有没有余量
            'ddl_kcgs': '',  # 课程归属
            'ddl_xqbs': 1,  # 上课校区
            'ddl_sksj': '',  # 上课时间
            'TextBox1': select.encode('gbk'),
            'Button2': '确定'.encode('gbk'),
            'dpkcmcGrid:txtChoosePage': 1,
            'dpkcmcGrid:txtPageSize': 15,
        }
        response = session.post(url, headers=headers, data=finddata)
        response = BeautifulSoup(response.text, 'lxml')
        __VIEWSTATE = response.find_all('input')[2]['value']
        try:
            course = response.find_all('fieldset')[1].find_all('tr')[1].find('td')
            if course != '':
                return '已经选了课'
        except:
            pass  # 不做任何事情，一般用做占位语句。
        selectdata = {
            '__EVENTTARGET': '',
            '__EVENTARGUMENT': '',
            '__VIEWSTATE': __VIEWSTATE,
            'ddl_kcxz': '',
            'ddl_ywyl': '有'.encode('gbk'),  # 有没有余量
            'ddl_kcgs': '',  # 课程归属
            'ddl_xqbs': 1,  # 上课校区
            'ddl_sksj': '',  # 上课时间
            'TextBox1': select.encode('gbk'),
            'kcmcGrid:_ctl2:xk': 'on',
            'kcmcGrid:_ctl2:jcnr': '|||',
            'dpkcmcGrid:txtChoosePage': 1,
            'dpkcmcGrid:txtPageSize': 15,
            'Button1': '  提交  '.encode('gbk'),
        }

        headers["Referer"] = url
        response = session.post(url, headers=headers, data=selectdata)
        response = BeautifulSoup(response.text, 'lxml')
        pattern = re.compile(".*?>alert(.*?);<.*?", re.S)
        try:
            badresult = re.findall(pattern, str(response))[0][2:-2]
            course = response.find_all('fieldset')[1].find_all('tr')[1].find('td')
            print(badresult)
            if badresult == '您已经修过该课程！不能再选':
                return '未完成'

            elif course == select:
                with open('success.txt', 'a+') as f:
                    f.write(self.username + '\t' + select + '\n')
                    f.close()
                    return '完成'

            else:
                print('抢课未成功' + '\n')
                with open('fault.txt', 'a+') as f:
                    f.write(self.username + '\t' + select + '\n')
                    f.close()
                    return '未完成'

        except:
            print('抢课未成功' + '\n')
            with open('fault.txt', 'a+') as f:
                f.write(self.username + '\t' + select + '\n')
                f.close()
            return '未完成'

    # 登录
    def login(self, session, username, password):
        # print(username, password)
        count, result = 0, ''
        imgUrl = self.urlhead + '/CheckCode.aspx?'
        Response = session.get(self.Login)
        soup = BeautifulSoup(Response.text, 'lxml')
        __VIEWSTATE = soup.find_all('input')[0]['value']
        print('尝试登录教务系统')

        while True:
            imgResponse = session.get(imgUrl, stream=True)
            with open('ver_pic.png', 'wb') as f:
                f.write(imgResponse.content)
            image = np.array(Image.open('ver_pic.png'))
            Image_code = self.crack_captcha(image, self.output, self.sess)

            Login_postData = {
                '__VIEWSTATE': __VIEWSTATE,
                'txtUserName': username,
                'TextBox2': password,
                'txtSecretCode': Image_code,
                'RadioButtonList1': "\xd1\xa7\xc9\xfa",
                'Button1': '',
                'lbLanguage': '',
                'hidPdrs': '',
                'hidsc': '',
            }

            response = session.post(self.Login, data=Login_postData, headers=self.headers)  # 尝试登录
            response = BeautifulSoup(response.text, 'lxml')
            try:
                result = response.find(id='xhxm').string
                result[-2:] != '同学'
                self.name = result[:-2]
                if result[:-2] == '陈鑫':
                    print(result)
                    # return Image_code
            except:
                count = count + 1
                print('失败')
                if count == 8:
                    with open('unlogin.txt', 'a+') as f:
                        f.write(username + '，' + password + '\n')
                        f.close()
                    return False
                continue

            self.username = username
            self.password = password
            break
        return True

    def randomm(self):
        return random.randint(0, len(self.selectcourselist) - 1)

    def random_course(self):
        return self.selectcourselist[self.randomm()]


if __name__ == '__main__':
    test = LoginZF()
    session = test.init()
    # 用test去调用LoginZF()的方法，记得带上session参数